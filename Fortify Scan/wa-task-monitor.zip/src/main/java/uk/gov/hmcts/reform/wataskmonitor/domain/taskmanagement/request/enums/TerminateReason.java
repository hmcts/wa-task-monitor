package uk.gov.hmcts.reform.wataskmonitor.domain.taskmanagement.request.enums;

public enum TerminateReason {
    COMPLETED, CANCELLED, DELETED
}
