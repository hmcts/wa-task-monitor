package uk.gov.hmcts.reform.wataskmonitor.domain.jobs.adhoc.updatecasedata;

public class UpdateCaseDataParameter {
}
