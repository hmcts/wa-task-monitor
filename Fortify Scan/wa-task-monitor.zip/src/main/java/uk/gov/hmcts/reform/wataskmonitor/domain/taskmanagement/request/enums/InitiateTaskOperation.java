package uk.gov.hmcts.reform.wataskmonitor.domain.taskmanagement.request.enums;

public enum InitiateTaskOperation {
    INITIATION
}
