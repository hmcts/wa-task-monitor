package uk.gov.hmcts.reform.wataskmonitor.domain.jobs;

public class JobReport {
}
